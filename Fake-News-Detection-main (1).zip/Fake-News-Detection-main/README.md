# Fake-News-Detection
Using various algorithms to classify whether the news is fake or real

Dataset link - https://drive.google.com/drive/folders/1Tt7Pv2iQU5x1-bhLdIKLhzdRJfKi94B_?usp=share_link
